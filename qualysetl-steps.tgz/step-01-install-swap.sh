#!/bin/bash

# This script creates a 4GB swap file on the root disk, formats it, activates it, and adds it to /etc/fstab for persistence.
# Run this script with sudo privileges: sudo ./script.sh

# Check if running as root
if [ "$EUID" -ne 0 ]; then
	  echo "Please run this script as root or with sudo."
	    exit 1
fi

# Create the swap file (4GB)
fallocate -l 6G /swapfile || {
	  echo "fallocate failed, using dd instead."
  dd if=/dev/zero of=/swapfile bs=1M count=4096
}

# Set permissions
chmod 600 /swapfile

# Format as swap
mkswap /swapfile

# Activate swap
swapon /swapfile

# Add to /etc/fstab for persistence (backup fstab first)
cp /etc/fstab /etc/fstab.bak
echo "/swapfile none swap sw 0 0" >> /etc/fstab

echo "Swap file created and activated. Verify with 'swapon --show'."
